package com.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sample.conn.JDBCConnection;
import com.sample.dto.DataDTO;

public class DataDAO {
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public List<DataDTO> selectDataList() {
		ArrayList<DataDTO> list = new ArrayList<DataDTO>();
		Connection conn = JDBCConnection.getConn();
		
		try {
			String sql = "select * from sampletable";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				DataDTO dto = new DataDTO();
				dto.setId(rs.getInt("id"));
				dto.setData1(rs.getString("data1"));
				dto.setData2(rs.getString("data2"));
				dto.setData3(rs.getString("data3"));
				list.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return list;
	}
	
	
	public DataDTO selectData(int id) {
		Connection conn = JDBCConnection.getConn();
		DataDTO dto = new DataDTO();
		
		try {
			String sql = "select * from sampletable where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				dto.setId(rs.getInt("id"));
				dto.setData1(rs.getString(2));
				dto.setData2(rs.getString(3));
				dto.setData3(rs.getString(4));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
		return dto;
	}
	
	public String insertData(DataDTO dto) {
		Connection conn = JDBCConnection.getConn();
		int i =0;
		try {
			String sql = "insert into sampletable(data1, data2, data3) values(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getData1());
			pstmt.setString(2, dto.getData2());
			pstmt.setString(3, dto.getData3());
			
			i = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (i>0) ? "저장되었습니다" : "저장되지 않았습니다";
	}
	
	
	public String updateData(DataDTO dto) {
		Connection conn = JDBCConnection.getConn();
		int i =0;
		try {
			String sql = "update sampletable set data1=?, data2=?, data3=? where id=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getData1());
			pstmt.setString(2, dto.getData2());
			pstmt.setString(3, dto.getData3());
			pstmt.setInt(4, dto.getId());
			
			i = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (i>0) ? "수정되었습니다" : "수정되지 않았습니다";
	}
	
	public void deleteData(int id) {
		Connection conn = JDBCConnection.getConn();
		
		try {
			String sql = "delete from sampletable where id= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	
}
