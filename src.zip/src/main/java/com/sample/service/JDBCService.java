package com.sample.service;

import javax.servlet.http.HttpServletRequest;

import com.sample.dao.DataDAO;
import com.sample.dto.DataDTO;

public class JDBCService {
	private DataDAO dao = new DataDAO();
	
	public void getList(HttpServletRequest request) {
		request.setAttribute("list", dao.selectDataList());
	}
	
	public void getItem(HttpServletRequest request) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("item", dao.selectData(id));
	}
	
	public void setItem(HttpServletRequest request) {
		DataDTO dto = new DataDTO();
		dto.setData1(request.getParameter("data1"));
		dto.setData2(request.getParameter("data2"));
		dto.setData3(request.getParameter("data3"));
		request.setAttribute("result", dao.insertData(dto));
	}
	
	public void patchItem(HttpServletRequest request) {
		DataDTO dto = new DataDTO();
		dto.setData1(request.getParameter("data1"));
		dto.setData2(request.getParameter("data2"));
		dto.setData3(request.getParameter("data3"));
		dto.setId(Integer.parseInt(request.getParameter("id")));
		request.setAttribute("patch", dao.updateData(dto));
	}
	
	public void deleteItem(HttpServletRequest request) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("delete", dao.deleteData(id));
	}
	
}
