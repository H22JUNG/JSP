package com.goodee.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;
import com.goodee.dao.DAO;
import com.goodee.vo.VO;

public class service1 {
	SqlSessionFactory factory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = factory.openSession();
	DAO dao = sqlSession.getMapper(DAO.class);

	public void listService1(HttpServletRequest request) {
		try {
			List<VO> list = dao.selectlist1();
			request.setAttribute("list", list);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService2(HttpServletRequest request) {

		try {
			VO vo = new VO();
			vo.setCategory(request.getParameter("category"));

			List<VO> list = dao.selectlist2(vo);
			request.setAttribute("list", list);

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void listService3(HttpServletRequest request) {
		try {
			List<VO> list = dao.selectlist3(request.getParameter("create"));
			request.setAttribute("list", list);

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void listService4(HttpServletRequest request) {
		try {
			String s = request.getParameter("start");
			String end = request.getParameter("end");
			List<VO> list = dao.selectlist4(s, end);
			request.setAttribute("list", list);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService5(HttpServletRequest request) {
		try {
			List<String> arrlist = new ArrayList<String>();
			//for(int i=0; i<request.getParameterValues("month").length; i++ ) {
			//	arrlist.add(request.getParameterValues("month")[i]);
			//}
			for(String list : request.getParameterValues("month")) {
				arrlist.add(list);
			}
			List<VO> list = dao.selectlist5(arrlist);
			request.setAttribute("list", list);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
