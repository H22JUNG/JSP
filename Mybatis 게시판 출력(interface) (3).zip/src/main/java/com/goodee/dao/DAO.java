package com.goodee.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.goodee.vo.VO;

public interface DAO {
	public List<VO> selectlist1();
	public List<VO> selectlist2(VO vo);
	public List<VO> selectlist3(String s);
	public List<VO> selectlist4(@Param("start")String start, @Param("end")String end);
	public List<VO> selectlist5(List<String> list);
}
