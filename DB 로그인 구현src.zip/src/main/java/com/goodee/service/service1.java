package com.goodee.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;
import com.goodee.vo.loginVO;
import com.goodee.vo.userVO;

public class service1 {
	SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = sqlSessionFactory.openSession();
	
	public void getuserlist(HttpServletRequest request) {
		
		loginVO vo = new loginVO();
		vo.setId(request.getParameter("id"));
		vo.setPw(request.getParameter("pw"));
		
		List<userVO> usvo = new ArrayList<userVO>();
		
		try {
			usvo = sqlSession.selectList("bbs.userlist", vo);
			request.setAttribute("list", usvo);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getbbslist(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.bbslist"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
