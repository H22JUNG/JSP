package com.goodee.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.goodee.service.service1;
import com.goodee.vo.loginVO;
import com.goodee.vo.userVO;

/**
 * Servlet implementation class Controller1
 */
@WebServlet("/Controller1")
public class Controller1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller1() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		service1 service = new service1();
		service.getuserlist(request);

		loginVO vo = new loginVO();
		vo.setId(request.getParameter("id"));
		vo.setPw(request.getParameter("pw"));

		List<userVO> usvo = (ArrayList<userVO>)request.getAttribute("list");

		if(usvo.size() != 0) {
			if(usvo.get(0).getUserid().equals(vo.getId()) && usvo.get(0).getPassword().equals(vo.getPw())){
				//같으면 컨트롤러 2로 보내기 -> 여기서 리스트 받아서 쏴주기
				RequestDispatcher rdp = request.getRequestDispatcher("Controller2");
				rdp.forward(request, response);
			} else {
				//틀리면 다시 로그인창
				RequestDispatcher rdp = request.getRequestDispatcher("/Login.jsp");
				rdp.forward(request, response);
			}
		} else {
			RequestDispatcher rdp = request.getRequestDispatcher("/Login.jsp");
			rdp.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
