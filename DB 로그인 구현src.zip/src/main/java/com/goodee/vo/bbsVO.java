package com.goodee.vo;

import org.apache.ibatis.type.Alias;

@Alias("bbsVO")
public class bbsVO {
	private int id;
	private String title;
	private String owner;
	private String content;
	private String createDate;
	public bbsVO() {
		// TODO Auto-generated constructor stub
	}
	public bbsVO(int id, String title, String owner, String createDate) {
		super();
		this.id = id;
		this.title = title;
		this.owner = owner;
		this.createDate = createDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	
}
