package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;

public class service1 {
	SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = sqlSessionFactory.openSession();
	
	public void getlist(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist1"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void getlistdesc(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist2"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist3(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist3"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist4(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist3"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist6(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist6"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist7(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist7"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist8(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist8"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void getlist9(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.selectlist9"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
