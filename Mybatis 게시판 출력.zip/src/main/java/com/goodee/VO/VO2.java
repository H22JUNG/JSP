package com.goodee.VO;

import org.apache.ibatis.type.Alias;

@Alias("VO2")
public class VO2 {
	private int id;
	private String title;
	private String owner;
	private String content;
	private String createDate;
	private String createTime;
	private int count;
	
	
	public VO2() {
		// TODO Auto-generated constructor stub
	}


	public VO2(int id, String title, String owner, String createDate, String createTime) {
		super();
		this.id = id;
		this.title = title;
		this.owner = owner;
		this.createDate = createDate;
		this.createTime = createTime;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getOwner() {
		return owner;
	}


	public void setOwner(String owner) {
		this.owner = owner;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getCreateDate() {
		return createDate;
	}


	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}


	public String getCreateTime() {
		return createTime;
	}


	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}
	
	
}
	