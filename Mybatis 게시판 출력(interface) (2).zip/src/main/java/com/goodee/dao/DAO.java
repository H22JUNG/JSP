package com.goodee.dao;

import java.util.List;

import com.goodee.vo.VO;

public interface DAO {
	public List<VO> selectlist1();
	public List<VO> selectlist2();
	public List<VO> selectlist3();
	public List<VO> selectlist6();
	public List<VO> selectlist7();
	public List<VO> selectlist8();
	public List<VO> selectlist9();
	
	public List<VO> insert1();
}
