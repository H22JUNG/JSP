package com.goodee.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;
import com.goodee.dao.DAO;
import com.goodee.vo.VO;

public class service2 {
	
	SqlSessionFactory factory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = factory.openSession();
	DAO dao = sqlSession.getMapper(DAO.class);
	List<VO> uplist = new ArrayList<VO>(); 
	
	
	public void insert(HttpServletRequest request) {
		try {
			VO vo = new VO();
			vo.setTitle(request.getParameter("title"));
			vo.setOwner(request.getParameter("owner"));
			vo.setContent(request.getParameter("content"));
			vo.setCategory(Integer.parseInt(request.getParameter("category")));
			
			System.out.println(vo.getCategory());
			
			uplist.add(vo);
			
			System.out.println(uplist);
			
			//List<VO> resultlist = dao.insert1(uplist);
			int i = sqlSession.insert("dao.insert1()", uplist);
			
			
			sqlSession.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
