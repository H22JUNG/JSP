package com.goodee.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;
import com.goodee.dao.DAO;
import com.goodee.vo.VO;

public class service1 {
	SqlSessionFactory factory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = factory.openSession();
	DAO dao = sqlSession.getMapper(DAO.class);
	
	public void listService1(HttpServletRequest request) {
		try {
			List<VO> list = dao.selectlist1();
			request.setAttribute("list", list);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void listService2(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist2());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService3(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist3());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService4(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist3());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService5(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist3());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService6(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist6());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService7(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist7());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService8(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist8());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void listService9(HttpServletRequest request) {
		try {
			request.setAttribute("list", dao.selectlist9());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
