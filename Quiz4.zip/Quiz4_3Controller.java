package com.goodee.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.goodee.bean.Quiz4_3Bean;

/**
 * Servlet implementation class Quiz4_3Controller
 */
@WebServlet("/Quiz4_3Controller")
public class Quiz4_3Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Quiz4_3Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		Quiz4_3Bean bean = new Quiz4_3Bean();
		bean.setTime(request.getParameter("time"));
		bean.setName(request.getParameter("name"));
		bean.setEmail2(request.getParameter("email2"));
		bean.setPw2(request.getParameter("pw2"));
		bean.setMajor(request.getParameter("major"));
		bean.setGender(request.getParameter("gender"));
		bean.setInter(request.getParameterValues("inter"));
		
		request.setAttribute("bean", bean);
		
		System.out.println("이름 : " + bean.getName());
		System.out.println("이메일 : " + bean.getEmail2());
		System.out.println("패스워드 : " + bean.getPw2());
		System.out.println("전공 : " + bean.getMajor());
		System.out.println("성별 : " + bean.getGender());
		for(int i= 0; i < bean.getInter().length; i++) {
			System.out.println("관심사 : " + bean.getInter()[i]);
		}
		
		RequestDispatcher rdp = request.getRequestDispatcher("/quiz1/quiz4_3result.jsp");
		rdp.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
