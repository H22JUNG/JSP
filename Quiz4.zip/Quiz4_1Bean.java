package com.goodee.bean;

public class Quiz4_1Bean {
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
