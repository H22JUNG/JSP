package com.goodee.bean;

public class Quiz4_3Bean {
	private String time;
	private String name;
	private String email2;
	private String pw2;
	private String major;
	private String gender;
	private String[] inter;
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail2() {
		return email2;
	}
	public void setEmail2(String email2) {
		this.email2 = email2;
	}
	public String getPw2() {
		return pw2;
	}
	public void setPw2(String pw2) {
		this.pw2 = pw2;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String[] getInter() {
		return inter;
	}
	public void setInter(String[] inter) {
		this.inter = inter;
	}
	
	
}
