package com.goodee.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.goodee.conf.SqlSessionManager;
import com.goodee.vo.userVO;

public class service1 {
	SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	SqlSession sqlSession = sqlSessionFactory.openSession();

	public boolean getuserlist(HttpServletRequest request) {

		//강사님 코드
		userVO vo = new userVO();
		vo.setUserid(request.getParameter("id"));
		vo.setPassword(request.getParameter("pw"));
		
		//userVO rerer = new userVO();
		//rerer = sqlSession.selectOne("bbs.userlist", vo);
		
		
		int i = sqlSession.selectOne("bbs.userlist", vo);
	//	System.out.println(vo.getUserid()+vo.getPassword());
	
	//	return (rerer != null)? true : false;
		return (i >0)? true : false;
		
		
		/*내가 짠 코드
		 * List<userVO> list = null;
		 

		Map<String, String> map = new HashMap<String, String>();
		map.put("id", request.getParameter("id"));
		map.put("pw", request.getParameter("pw"));

		try {
			list = sqlSession.selectList("bbs.userlist", map);
			System.out.println(sqlSession.selectList("bbs.userlist", map));

		}catch(Exception e) {
			e.printStackTrace();
		}
		if(list.size() != 0) {
			if(list.get(0).getUserid().equals(map.get("id")) 
					&& list.get(0).getPassword().equals(map.get("pw"))) {
				request.setAttribute("list", list);
				return true;
			}else {
				return false;
			}
		} else {
			return false;
		}
		*/
	}
	public void getbbslist(HttpServletRequest request) {
		try {
			request.setAttribute("list", sqlSession.selectList("bbs.bbslist"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
