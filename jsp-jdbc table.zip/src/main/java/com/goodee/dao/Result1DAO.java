package com.goodee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.goodee.conn.JDBCConnection;
import com.goodee.vo.BoardVO;

public class Result1DAO {
	Connection conn = JDBCConnection.getConn();
	
	public List<BoardVO> selectBoardList() {
		List<BoardVO> list = new ArrayList<BoardVO>();
		
		String sql = "select id, title, owner, DATE_FORMAT(createdate, '%Y-%m-%d') createdate from boardtable";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				list.add(new BoardVO(
						rs.getInt("id"),
						rs.getString("title"),
						rs.getString("owner"),
						rs.getString("createdate")
						));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}
