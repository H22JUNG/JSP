package com.goodee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.goodee.conn.JDBCConnection;
import com.goodee.vo.BoardVO2;

public class Result2DAO {
	Connection conn = JDBCConnection.getConn();
	
	public List<BoardVO2> gettable() {
		List<BoardVO2> list = new ArrayList<BoardVO2>();
		String sql = "select id, title, owner, DATE_FORMAT(createdate, '%Y-%m-%d') createdate, modifier, DATE_FORMAT(modifydate, '%Y-%m-%d') modifydate from `boardtable２`";
		
		//String sql = "select * from  `boardtable２`";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
					list.add(new BoardVO2(
							rs.getInt(1),
							rs.getString(2),
							rs.getString(3),
							rs.getString(4),
							rs.getString(5),
							rs.getString(6)
							));
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return list;
	}
}	
