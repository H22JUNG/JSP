package com.goodee.service;


import javax.servlet.http.HttpServletRequest;

import com.goodee.dao.Result2DAO;

public class Result2Service {
	public void getlist(HttpServletRequest request) {
		Result2DAO dao = new Result2DAO();
		request.setAttribute("list", dao.gettable());
	}
}
