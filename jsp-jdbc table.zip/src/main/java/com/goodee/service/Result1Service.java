package com.goodee.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.goodee.dao.Result1DAO;
import com.goodee.vo.BoardVO;

public class Result1Service {
	public void getBoardList(HttpServletRequest request) {
		// 게시판에 뿌릴 데이터 가져오기
		Result1DAO dao = new Result1DAO();
		//List<BoardVO> list = dao.selectBoardList();
		
		//게시판에 뿌릴 -> 테이블에 있는 내용 list라는 이름으로 request에 담기
		//request.setAttribute("list", list);
		request.setAttribute("list", dao.selectBoardList());
		//한줄로 작성하기
	}
	
	
}
