package com.goodee.vo;

public class BoardVO2 {
	private int id;
	private String title;
	private String owner;
	private String createdate;
	private String modifier;
	private String modifydate;
	
	public BoardVO2() {
		// TODO Auto-generated constructor stub
	}

	public BoardVO2(int id, String title, String owner, String createdate, String modifier, String modifydate) {
		super();
		this.id = id;
		this.title = title;
		this.owner = owner;
		this.createdate = createdate;
		this.modifier = modifier;
		this.modifydate = modifydate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getCreatedate() {
		return createdate;
	}

	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifydate() {
		return modifydate;
	}

	public void setModifydate(String modifydate) {
		this.modifydate = modifydate;
	}
	
	
}
