package com.goodee.conn;

import java.sql.Connection;
import java.sql.DriverManager;

//JDBC Connection을 세팅하고 제공해주는 클래스
public class JDBCConnection {
	//커넥션 연결-해제 반복하면 리소스 소모가 커서
	//한번 연결해놓고 계속 돌려쓰는 형태로 활용함 => 싱글턴 패턴
	private static String connect = "jdbc:mariadb://localhost:3306/bbs1";
	private static String user = "root";
	private static String password = "1234";
	
	private static Connection conn = null;
	
	//커넥션 초기화 로직
	static { 
		try {
			//어떤 드라이브 가져올지 강제함(jar 어딨는지 알려줌)
			//import org.mariadb.jdbc.Driver 랑 같은 역할 하지만
			//직접 연결이 잘 안되기 때문에 명시적으로 씀
			Class.forName("org.mariadb.jdbc.Driver");
			conn = DriverManager.getConnection(connect, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Connection getConn() {
		return conn; //conn getter만
	}
	

}
