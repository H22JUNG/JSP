package com.goodee.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.goodee.VO.VO1;
import com.goodee.conn.JDBCConnection;

public class DAO6 {
Connection conn = JDBCConnection.getConn();
	
	public List<VO1> volist() {
		List<VO1> list = new ArrayList<VO1>();
		String sql = "select id, title, owner, DATE_FORMAT(create_date, '%Y-%m-%d') create_date from bbs order by create_date DESC";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				list.add(new VO1(
						rs.getInt("id"),
						rs.getString("title"),
						rs.getString("owner"),
						rs.getString("create_date")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}
