package com.goodee.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.goodee.VO.VO1;
import com.goodee.VO.VO2;
import com.goodee.conn.JDBCConnection;

public class DAO9 {
Connection conn = JDBCConnection.getConn();
	
	public List<VO2> volist() {
		List<VO2> list = new ArrayList<VO2>();
		String sql = "select id, title, owner, DATE_FORMAT(create_date, '%Y-%m-%d') create_date, (select count(*) from bbs) count from bbs order by create_date DESC limit 14";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				VO2 vo2= new VO2();
				vo2.setId(rs.getInt("id"));
				vo2.setTitle(rs.getString("title"));
				vo2.setOwner(rs.getString("owner"));
				vo2.setCreate_date(rs.getString("create_date"));
				vo2.setCount(rs.getInt("count"));
				list.add(vo2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}
