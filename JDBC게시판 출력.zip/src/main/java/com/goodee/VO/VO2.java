package com.goodee.VO;

public class VO2 {
	private int id;
	private String title;
	private String owner;
	private String content;
	private String create_date;
	private String create_time;
	private int count;
	
	
	public VO2() {
		// TODO Auto-generated constructor stub
	}
	
	
	public VO2(int id, String title, String owner, String create_date, String create_time) {
		super();
		this.id = id;
		this.title = title;
		this.owner = owner;
		this.create_date = create_date;
		this.create_time = create_time;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	
}
