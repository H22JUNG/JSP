package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO3;
import com.goodee.DAO.DAO4;
import com.goodee.DAO.DAO5;
import com.goodee.DAO.DAO6;
import com.goodee.DAO.DAO7;

public class service7 {
	public void listService(HttpServletRequest request) {
		DAO7 dao = new DAO7();
		request.setAttribute("list", dao.volist());
		}
}
