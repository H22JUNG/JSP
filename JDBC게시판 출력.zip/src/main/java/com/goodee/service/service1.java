package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO1;

public class service1 {
	public void listService(HttpServletRequest request) {
	DAO1 dao = new DAO1();
	request.setAttribute("list", dao.volist());
	}
}
