package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO2;

public class service2 {
	public void listService(HttpServletRequest request) {
		DAO2 dao = new DAO2();
		request.setAttribute("list", dao.volist());
		}
}
