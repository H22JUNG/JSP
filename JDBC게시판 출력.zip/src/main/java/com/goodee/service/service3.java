package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO3;

public class service3 {
	public void listService(HttpServletRequest request) {
		DAO3 dao = new DAO3();
		request.setAttribute("list", dao.volist());
		}
}
