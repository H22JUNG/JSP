package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO3;
import com.goodee.DAO.DAO4;

public class service4 {
	public void listService(HttpServletRequest request) {
		DAO4 dao = new DAO4();
		request.setAttribute("list", dao.volist());
		}
}
