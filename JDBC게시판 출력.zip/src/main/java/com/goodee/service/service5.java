package com.goodee.service;

import javax.servlet.http.HttpServletRequest;

import com.goodee.DAO.DAO3;
import com.goodee.DAO.DAO4;
import com.goodee.DAO.DAO5;

public class service5 {
	public void listService(HttpServletRequest request) {
		DAO5 dao = new DAO5();
		request.setAttribute("list", dao.volist());
		}
}
